# Video chapter generation
Our model is two stage. First, we generate video chapter segmentation points. Then, we generate chapter title based on the text content in each chapter segment.

## training video segment model
run train.py

## testing video segment model
run test_video_segment_point.py


## training chapter title generation model
run train_chapter_title_gen.py

## testing chapter title generation model
run test_chapter_title_gen.py



