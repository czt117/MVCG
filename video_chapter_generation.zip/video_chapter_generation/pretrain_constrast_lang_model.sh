
python3 pretrain_constrast_lang_model.py --gpu 0 --batch_size 256


