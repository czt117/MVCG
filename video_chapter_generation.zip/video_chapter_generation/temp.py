# from transformers import LongformerConfig, LongformerModel

# # Initializing a Longformer configuration
# configuration = LongformerConfig()

# # Initializing a model from the configuration
# model = LongformerModel(configuration)

# # Accessing the model configuration
# configuration = model.config



import torch
a = torch.tensor([[[1, 2, 3, 4], [5, 6, 7, 8]], [[11, 22, 33, 44], [0, 0, 0, 0]]]).float()
b = torch.tensor([[1, 1], [1, 0]]).long()
aa = torch.sum(a, dim=1)
bb = torch.sum(b, dim=1).view(-1, 1)
print(aa / bb)


a = torch.tensor([[[1, 2, 3, 4], [5, 6, 7, 8]], [[11, 22, 33, 44], [55, 66, 77, 88]]])
b = torch.tensor([1, 1, 0, 0])
b = b.view(1, 1, -1)
# b = b.repeat(a.size(0), 1)
print(a*b)



import re

s = "- chicken bacon alfredo french bread:"
start_idx = 0
for i in range(len(s)):
    if s[i].isalnum():
        start_idx = i
        break

end_idx = len(s)
for i in reversed(range(len(s))):
    if s[i].isalnum():
        end_idx = i + 1
        break

clean_s = s[start_idx:end_idx]


# clean_s = re.sub(r'[^a-zA-Z0-9|# ]+', '', s)
# clean_s = [x for x in clean_s.split(" ") if len(x) > 0]
# clean_s = " ".join(clean_s)
print(clean_s)

