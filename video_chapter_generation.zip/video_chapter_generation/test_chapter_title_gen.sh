python3 test_chapter_title_gen.py --data_mode all --location_type gt --model_type bigbird --gpu 1
python3 test_chapter_title_gen.py --data_mode easy --location_type gt --model_type bigbird --gpu 1
python3 test_chapter_title_gen.py --data_mode hard --location_type gt --model_type bigbird --gpu 1

python3 test_chapter_title_gen.py --data_mode all --location_type pred --model_type bigbird --gpu 1
python3 test_chapter_title_gen.py --data_mode easy --location_type pred --model_type bigbird --gpu 1
python3 test_chapter_title_gen.py --data_mode hard --location_type pred --model_type bigbird --gpu 1

# python3 test_chapter_title_gen.py --data_mode all --location_type gt --model_type pegasus --gpu 2
# python3 test_chapter_title_gen.py --data_mode easy --location_type gt --model_type pegasus --gpu 2
# python3 test_chapter_title_gen.py --data_mode hard --location_type gt --model_type pegasus --gpu 2

# python3 test_chapter_title_gen.py --data_mode all --location_type pred --model_type pegasus --gpu 2
# python3 test_chapter_title_gen.py --data_mode easy --location_type pred --model_type pegasus --gpu 2
# python3 test_chapter_title_gen.py --data_mode hard --location_type pred --model_type pegasus --gpu 2


