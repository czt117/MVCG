mkdir all_tensorboards
find . -name "events*" | xargs cp --parents -t ./all_tensorboards