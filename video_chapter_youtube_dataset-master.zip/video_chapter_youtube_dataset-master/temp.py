import json


clip_test_file = "./dataset/test_clips_clip_frame_num_16.json"
with open(clip_test_file, "r") as f:
    data = json.load(f)


all_vids_set = set()
for clip_info in data:
    vid = clip_info["vid"]
    all_vids_set.add(vid)



all_vids = []
vid = ""
gt_labels = []
prev_clip_info = None
for clip_info in data:
    if vid != clip_info["vid"]:
        if len(gt_labels) > 0:
            if 1 not in gt_labels:
                print(vid)
                print()
        
        vid = clip_info["vid"]
        all_vids.append(vid)
        prev_clip_info = clip_info

        pred_scores = []
        gt_labels = []
    gt_labels.append(clip_info["clip_label"])


assert len(all_vids_set) == len(all_vids)



print()



