# python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 6
python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 8
# python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 10
python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 12
# python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 14
python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 16
python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 20
python3 ./dataset_process_scripts/flat_video2clip_for_quick_infer.py --clip_frame_num 24

